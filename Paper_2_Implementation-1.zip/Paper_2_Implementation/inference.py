import argparse
from model import CounterMisinformationGenerator
from rewards import combined_reward


def main(args):
    generator = CounterMisinformationGenerator(args.checkpoint)

    response = generator.generate(
        args.misinformation,
        args.evidence,
        max_new_tokens=args.max_new_tokens,
        do_sample=False,
    )

    reward, parts = combined_reward(
        args.misinformation, response, args.evidence
    )

    print("\nMisinformation:")
    print(args.misinformation)
    print("\nCounter-misinformation response:")
    print(response)
    print("\nReward:", round(reward, 4))
    print("Reward components:", parts)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--checkpoint", default="outputs")
    p.add_argument("--misinformation", required=True)
    p.add_argument("--evidence", default="")
    p.add_argument("--max_new_tokens", type=int, default=80)
    main(p.parse_args())
