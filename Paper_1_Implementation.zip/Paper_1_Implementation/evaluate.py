import argparse

import torch
from torch.utils.data import DataLoader
from transformers import AutoTokenizer
from sklearn.metrics import classification_report, accuracy_score

from dataset import load_csv, JointDataset
from model import JointRumorModel


def main(args):

    device = torch.device(
        "cuda" if torch.cuda.is_available() else "cpu"
    )

    checkpoint = torch.load(
        args.checkpoint,
        map_location=device,
    )

    model_name = checkpoint["model_name"]

    tokenizer = AutoTokenizer.from_pretrained(
        args.tokenizer_dir
    )

    df = load_csv(
        args.csv,
        args.max_rows,
    )

    dataset = JointDataset(
        df,
        tokenizer,
        max_length=args.max_length,
    )

    loader = DataLoader(
        dataset,
        batch_size=args.batch_size,
    )

    model = JointRumorModel(
        model_name=model_name,
        num_stance=4,
        num_veracity=4,
    ).to(device)

    model.load_state_dict(checkpoint["model"])
    model.eval()

    stance_true = []
    stance_pred = []

    veracity_true = []
    veracity_pred = []

    with torch.no_grad():

        for batch in loader:

            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)

            stance_logits, veracity_logits, _ = model(
                input_ids,
                attention_mask,
            )

            stance_true.extend(
                batch["stance"].tolist()
            )

            stance_pred.extend(
                stance_logits.argmax(dim=-1)
                .cpu()
                .tolist()
            )

            veracity_true.extend(
                batch["veracity"].tolist()
            )

            veracity_pred.extend(
                veracity_logits.argmax(dim=-1)
                .cpu()
                .tolist()
            )

    print("\n===== STANCE DETECTION =====")

    print(
        "Accuracy:",
        accuracy_score(
            stance_true,
            stance_pred,
        ),
    )

    print(
        classification_report(
            stance_true,
            stance_pred,
            target_names=[
                "Support",
                "Deny",
                "Question",
                "Comment",
            ],
            zero_division=0,
        )
    )

    print("\n===== RUMOR VERIFICATION =====")

    print(
        "Accuracy:",
        accuracy_score(
            veracity_true,
            veracity_pred,
        ),
    )

    print(
        classification_report(
            veracity_true,
            veracity_pred,
            target_names=[
                "Non-Rumor",
                "True Rumor",
                "False Rumor",
                "Unverified Rumor",
            ],
            zero_division=0,
        )
    )


if __name__ == "__main__":

    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--csv",
        default="data/sample.csv",
    )

    parser.add_argument(
        "--checkpoint",
        default="outputs/checkpoint.pt",
    )

    parser.add_argument(
        "--tokenizer_dir",
        default="outputs",
    )

    parser.add_argument(
        "--batch_size",
        type=int,
        default=8,
    )

    parser.add_argument(
        "--max_length",
        type=int,
        default=128,
    )

    parser.add_argument(
        "--max_rows",
        type=int,
        default=100,
    )

    main(parser.parse_args())
