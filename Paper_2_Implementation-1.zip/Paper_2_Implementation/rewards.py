import re
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


POLITE = {
    "please", "thank", "understand", "respect", "evidence",
    "information", "help", "consider", "important"
}
AGGRESSIVE = {
    "idiot", "stupid", "dumb", "moron", "shut up", "hate"
}

REFUTATION = {
    "false", "not", "no evidence", "incorrect", "misleading",
    "does not", "do not", "cannot", "cannot be", "unsupported",
    "untrue", "debunk", "evidence shows"
}


def _tokens(text):
    return set(re.findall(r"[a-zA-Z]{3,}", text.lower()))


def relevance_reward(claim, response):
    if not response.strip():
        return 0.0
    try:
        v = TfidfVectorizer(stop_words="english").fit_transform(
            [claim, response]
        )
        return float(cosine_similarity(v[0:1], v[1:2])[0, 0])
    except Exception:
        return 0.0


def evidence_reward(evidence, response):
    if not evidence.strip() or not response.strip():
        return 0.0
    try:
        v = TfidfVectorizer(stop_words="english").fit_transform(
            [evidence, response]
        )
        return float(cosine_similarity(v[0:1], v[1:2])[0, 0])
    except Exception:
        return 0.0


def refutation_reward(response):
    text = response.lower()
    hits = sum(1 for phrase in REFUTATION if phrase in text)
    return min(1.0, hits / 2.0)


def politeness_reward(response):
    text = response.lower()
    words = _tokens(text)
    good = len(words & POLITE)
    bad = sum(1 for phrase in AGGRESSIVE if phrase in text)
    score = 0.5 + 0.1 * min(good, 5) - 0.25 * min(bad, 2)
    return float(np.clip(score, 0.0, 1.0))


def fluency_reward(response):
    text = response.strip()
    if not text:
        return 0.0
    words = text.split()
    if len(words) < 4:
        return 0.3
    unique_ratio = len(set(w.lower() for w in words)) / len(words)
    repeated_penalty = max(0.0, 1.0 - unique_ratio)
    return float(np.clip(1.0 - repeated_penalty, 0.0, 1.0))


def lexical_reference_reward(reference, response):
    if not reference.strip() or not response.strip():
        return 0.0
    a, b = _tokens(reference), _tokens(response)
    if not a:
        return 0.0
    return len(a & b) / len(a)


def combined_reward(claim, response, evidence="", reference=""):
    rel = relevance_reward(claim, response)
    ref = refutation_reward(response)
    fact = evidence_reward(evidence, response) if evidence.strip() else 0.0
    pol = politeness_reward(response)
    flu = fluency_reward(response)

    # If a reference response exists, use it as an additional training signal.
    ref_text = lexical_reference_reward(reference, response) if reference else 0.0

    # Transparent weighted reward for the assessment implementation.
    reward = (
        0.25 * rel +
        0.25 * ref +
        0.20 * fact +
        0.15 * pol +
        0.10 * flu +
        0.05 * ref_text
    )

    return float(reward), {
        "relevance": rel,
        "refutation": ref,
        "evidence": fact,
        "politeness": pol,
        "fluency": flu,
        "reference": ref_text,
    }
