import torch
import torch.nn as nn
from transformers import AutoModel


class JointRumorModel(nn.Module):
    """
    Shared encoder with two prediction heads:
      - stance detection
      - rumor verification
    """

    def __init__(
        self,
        model_name="distilbert-base-uncased",
        num_stance=4,
        num_veracity=4,
        dropout=0.1,
    ):
        super().__init__()

        self.encoder = AutoModel.from_pretrained(model_name)
        hidden = self.encoder.config.hidden_size

        self.dropout = nn.Dropout(dropout)
        self.stance_head = nn.Linear(hidden, num_stance)
        self.veracity_head = nn.Linear(hidden, num_veracity)

    def forward(self, input_ids, attention_mask):
        output = self.encoder(
            input_ids=input_ids,
            attention_mask=attention_mask,
        )

        # DistilBERT does not have a pooler.
        pooled = output.last_hidden_state[:, 0]
        pooled = self.dropout(pooled)

        stance_logits = self.stance_head(pooled)
        veracity_logits = self.veracity_head(pooled)

        return stance_logits, veracity_logits, pooled
