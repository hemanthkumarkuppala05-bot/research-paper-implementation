import argparse
import os
import random
import numpy as np
import torch
from torch.optim import AdamW
from tqdm import tqdm

from dataset import load_csv
from model import CounterMisinformationGenerator
from rewards import combined_reward


def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def supervised_warmup(generator, df, epochs, lr, max_new_tokens):
    """Teacher-forcing warm-up using the reference counter-response."""
    optimizer = AdamW(generator.model.parameters(), lr=lr)
    generator.model.train()

    for epoch in range(epochs):
        losses = []
        for _, row in tqdm(df.iterrows(), total=len(df),
                            desc=f"supervised epoch {epoch+1}"):
            prompt = generator.prompt(row["misinformation"], row["evidence"])
            source = generator.tokenizer(
                prompt, return_tensors="pt", truncation=True, max_length=256
            ).to(generator.device)
            target = generator.tokenizer(
                str(row["response"]), return_tensors="pt",
                truncation=True, max_length=128
            ).input_ids.to(generator.device)

            labels = target.clone()
            labels[labels == generator.tokenizer.pad_token_id] = -100

            out = generator.model(
                input_ids=source.input_ids,
                attention_mask=source.attention_mask,
                labels=labels,
            )
            optimizer.zero_grad()
            out.loss.backward()
            torch.nn.utils.clip_grad_norm_(generator.model.parameters(), 1.0)
            optimizer.step()
            losses.append(float(out.loss.item()))

        print(f"supervised_loss={np.mean(losses):.4f}")


def reinforce(generator, df, epochs, lr, max_new_tokens, baseline_momentum=0.9):
    """
    REINFORCE:
      response ~ policy
      reward = quality(response)
      loss = -reward * log P(response | misinformation, evidence)
    """
    optimizer = AdamW(generator.model.parameters(), lr=lr)
    generator.model.train()
    baseline = 0.0

    for epoch in range(epochs):
        rewards = []
        for _, row in tqdm(df.iterrows(), total=len(df),
                            desc=f"RL epoch {epoch+1}"):

            # Sampling is performed without gradient; log probability is
            # calculated for the sampled response in a second pass.
            response = generator.generate(
                row["misinformation"],
                row["evidence"],
                max_new_tokens=max_new_tokens,
                do_sample=True,
                temperature=1.0,
                top_p=0.9,
            )

            reward, parts = combined_reward(
                row["misinformation"],
                response,
                row["evidence"],
                row["response"],
            )

            baseline = baseline_momentum * baseline + (1-baseline_momentum) * reward
            advantage = reward - baseline

            logp = generator.sequence_logprob(
                row["misinformation"], response, row["evidence"]
            )

            # Stop gradients through reward/advantage.
            loss = -(torch.tensor(advantage, device=logp.device) * logp)

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(generator.model.parameters(), 1.0)
            optimizer.step()

            rewards.append(reward)

        print(f"rl_reward={np.mean(rewards):.4f} baseline={baseline:.4f}")


def main(args):
    seed_everything(args.seed)
    os.makedirs(args.output_dir, exist_ok=True)

    df = load_csv(args.csv, args.max_rows)
    print(f"Loaded {len(df)} training examples.")

    generator = CounterMisinformationGenerator(args.model_name)

    if args.sup_epochs > 0:
        supervised_warmup(
            generator, df, args.sup_epochs, args.lr,
            args.max_new_tokens
        )

    if args.rl_epochs > 0:
        reinforce(
            generator, df, args.rl_epochs, args.rl_lr,
            args.max_new_tokens
        )

    generator.model.save_pretrained(args.output_dir)
    generator.tokenizer.save_pretrained(args.output_dir)
    print(f"Saved model to {args.output_dir}")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--csv", default="data/sample.csv")
    p.add_argument("--model_name", default="google/flan-t5-small")
    p.add_argument("--output_dir", default="outputs")
    p.add_argument("--max_rows", type=int, default=100)
    p.add_argument("--sup_epochs", type=int, default=1)
    p.add_argument("--rl_epochs", type=int, default=1)
    p.add_argument("--lr", type=float, default=2e-5)
    p.add_argument("--rl_lr", type=float, default=1e-5)
    p.add_argument("--max_new_tokens", type=int, default=64)
    p.add_argument("--seed", type=int, default=42)
    main(p.parse_args())
