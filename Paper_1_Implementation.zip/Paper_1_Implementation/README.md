# Paper 1 — Lightweight Implementation

**Paper:** Yang et al. (2024), *Reinforcement Tuning for Detecting Stances and Debunking Rumors Jointly with Large Language Models.*

This implementation is a resource-efficient proof of concept of the paper's main methodology.

## Core idea

The paper jointly considers:

1. **Stance Detection (SD)** — classify a social-media post as Support, Deny, Question, or Comment.
2. **Rumor Verification (RV)** — classify the claim/rumor veracity.
3. **Reinforcement label selection** — learn whether an example should be retained or discarded.
4. **Joint optimization** — use the quality of selected examples to improve the downstream models.

## Computational modifications

The original approach uses large LLMs and large datasets. For this assessment implementation:

- `distilbert-base-uncased` is used instead of a 7B-scale LLM.
- A small CSV subset can be used.
- Batch size and sequence length are configurable.
- Training epochs are small by default.
- A lightweight two-action RL selector is used: **RETAIN** or **DISCARD**.
- The selector uses an epsilon-greedy policy and a REINFORCE-style update.
- The reward is based on stance and rumor-verification correctness.

These modifications are necessary to run the implementation on a normal laptop/free Colab GPU while preserving the main methodology.

## Dataset

CSV columns:

```text
claim,post,stance,veracity
```

Example:

```csv
claim,post,stance,veracity
"Vaccines contain microchips","This claim is false and has no evidence.","Deny","False Rumor"
```

Labels:

### Stance
- Support
- Deny
- Question
- Comment

### Veracity
- Non-Rumor
- True Rumor
- False Rumor
- Unverified Rumor

A sample dataset is included in `data/sample.csv`.

## Install

```bash
pip install -r requirements.txt
```

## Train

```bash
python train.py   --csv data/sample.csv   --epochs 2   --batch_size 4
```

## Evaluate

```bash
python evaluate.py   --csv data/sample.csv   --checkpoint outputs/checkpoint.pt
```

## Inference

```bash
python inference.py   --checkpoint outputs/checkpoint.pt   --claim "Vaccines contain microchips"   --post "There is no evidence for this claim."
```

## Method

```text
Claim + Post
     |
     v
Shared Transformer Encoder
     |
     +------------------+
     |                  |
     v                  v
Stance Classifier   Rumor Classifier
     |                  |
     +--------+---------+
              |
              v
        Joint features
              |
              v
        RL Selector
       /              RETAIN         DISCARD
       |
       v
Selected training examples
       |
       v
Hybrid reward
       |
       v
Policy update
```

## Important

This is a **lightweight proof-of-concept**, not an exact reproduction of the paper's reported experiments. Do not claim the paper's reported numbers as your own results.
