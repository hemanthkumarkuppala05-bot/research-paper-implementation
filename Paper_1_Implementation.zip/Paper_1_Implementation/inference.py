import argparse

import torch
from transformers import AutoTokenizer

from model import JointRumorModel


def main(args):

    device = torch.device(
        "cuda" if torch.cuda.is_available() else "cpu"
    )

    checkpoint = torch.load(
        args.checkpoint,
        map_location=device,
    )

    tokenizer = AutoTokenizer.from_pretrained(
        args.tokenizer_dir
    )

    model = JointRumorModel(
        model_name=checkpoint["model_name"],
        num_stance=4,
        num_veracity=4,
    ).to(device)

    model.load_state_dict(
        checkpoint["model"]
    )

    model.eval()

    encoded = tokenizer(
        args.claim,
        args.post,
        truncation=True,
        padding="max_length",
        max_length=args.max_length,
        return_tensors="pt",
    )

    encoded = {
        k: v.to(device)
        for k, v in encoded.items()
    }

    with torch.no_grad():

        stance_logits, veracity_logits, _ = model(
            encoded["input_ids"],
            encoded["attention_mask"],
        )

    stance_id = stance_logits.argmax(
        dim=-1
    ).item()

    veracity_id = veracity_logits.argmax(
        dim=-1
    ).item()

    stance_labels = checkpoint[
        "stance_labels"
    ]

    veracity_labels = checkpoint[
        "veracity_labels"
    ]

    print("\nClaim:")
    print(args.claim)

    print("\nPost:")
    print(args.post)

    print("\nPredicted stance:")
    print(stance_labels[stance_id])

    print("\nPredicted veracity:")
    print(veracity_labels[veracity_id])


if __name__ == "__main__":

    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--checkpoint",
        default="outputs/checkpoint.pt",
    )

    parser.add_argument(
        "--tokenizer_dir",
        default="outputs",
    )

    parser.add_argument(
        "--claim",
        required=True,
    )

    parser.add_argument(
        "--post",
        required=True,
    )

    parser.add_argument(
        "--max_length",
        type=int,
        default=128,
    )

    main(parser.parse_args())
