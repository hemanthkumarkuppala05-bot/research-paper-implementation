import torch
import torch.nn as nn
from torch.distributions import Categorical


class RLSelector(nn.Module):
    """
    Two-action policy:
      0 = DISCARD
      1 = RETAIN
    """

    def __init__(self, feature_size):
        super().__init__()

        self.policy = nn.Sequential(
            nn.Linear(feature_size, feature_size // 2),
            nn.Tanh(),
            nn.Linear(feature_size // 2, 2),
        )

    def forward(self, features):
        return self.policy(features)


def epsilon_greedy_action(selector, features, epsilon=0.1):
    logits = selector(features)
    probabilities = torch.softmax(logits, dim=-1)

    if torch.rand(1).item() < epsilon:
        actions = torch.randint(
            low=0,
            high=2,
            size=(features.size(0),),
            device=features.device,
        )
    else:
        actions = Categorical(probabilities).sample()

    return actions, probabilities


def reinforce_loss(selector, features, actions, rewards):
    logits = selector(features)

    distribution = Categorical(logits=logits)
    log_prob = distribution.log_prob(actions)

    baseline = rewards.mean().detach()
    advantage = rewards.detach() - baseline

    return -(log_prob * advantage).mean()
