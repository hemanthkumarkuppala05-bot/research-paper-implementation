import pandas as pd
from torch.utils.data import Dataset


def load_csv(path, max_rows=None):
    df = pd.read_csv(path).fillna("")
    required = {"misinformation", "response"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    if "evidence" not in df.columns:
        df["evidence"] = ""

    df = df[["misinformation", "response", "evidence"]]
    if max_rows:
        df = df.head(max_rows)

    return df.reset_index(drop=True)


class ResponseDataset(Dataset):
    def __init__(self, df):
        self.df = df.reset_index(drop=True)

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        return {
            "misinformation": str(row["misinformation"]),
            "response": str(row["response"]),
            "evidence": str(row["evidence"]),
        }
