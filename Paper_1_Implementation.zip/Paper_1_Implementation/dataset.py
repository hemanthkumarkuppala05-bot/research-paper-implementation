import pandas as pd
import torch
from torch.utils.data import Dataset

STANCE_LABELS = ["Support", "Deny", "Question", "Comment"]
VERACITY_LABELS = [
    "Non-Rumor",
    "True Rumor",
    "False Rumor",
    "Unverified Rumor",
]

STANCE2ID = {x.lower(): i for i, x in enumerate(STANCE_LABELS)}
VERACITY2ID = {x.lower(): i for i, x in enumerate(VERACITY_LABELS)}


def load_csv(path, max_rows=None):
    df = pd.read_csv(path).fillna("")

    required = {"claim", "post", "stance", "veracity"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing columns: {missing}")

    if max_rows is not None:
        df = df.head(max_rows)

    return df.reset_index(drop=True)


class JointDataset(Dataset):
    def __init__(self, df, tokenizer, max_length=128):
        self.df = df
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]

        encoded = self.tokenizer(
            str(row["claim"]),
            str(row["post"]),
            truncation=True,
            padding="max_length",
            max_length=self.max_length,
            return_tensors="pt",
        )

        stance = STANCE2ID[str(row["stance"]).lower().strip()]
        veracity = VERACITY2ID[str(row["veracity"]).lower().strip()]

        return {
            "input_ids": encoded["input_ids"].squeeze(0),
            "attention_mask": encoded["attention_mask"].squeeze(0),
            "stance": torch.tensor(stance, dtype=torch.long),
            "veracity": torch.tensor(veracity, dtype=torch.long),
        }
