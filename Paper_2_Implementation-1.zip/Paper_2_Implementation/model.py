import torch
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM


class CounterMisinformationGenerator:
    def __init__(self, model_name="google/flan-t5-small", device=None):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForSeq2SeqLM.from_pretrained(model_name).to(self.device)

    def prompt(self, misinformation, evidence=""):
        if evidence.strip():
            return (
                "Write a polite, factual counter-misinformation response. "
                "Correct the claim using the evidence. "
                f"Misinformation: {misinformation} "
                f"Evidence: {evidence} "
                "Response:"
            )
        return (
            "Write a polite factual response that corrects this misinformation. "
            f"Misinformation: {misinformation} Response:"
        )

    def generate(self, misinformation, evidence="", max_new_tokens=80,
                 do_sample=True, temperature=0.9, top_p=0.9):
        prompt = self.prompt(misinformation, evidence)
        x = self.tokenizer(
            prompt, return_tensors="pt", truncation=True, max_length=256
        ).to(self.device)

        with torch.no_grad():
            y = self.model.generate(
                **x,
                max_new_tokens=max_new_tokens,
                do_sample=do_sample,
                temperature=temperature,
                top_p=top_p,
                num_return_sequences=1,
            )

        return self.tokenizer.decode(y[0], skip_special_tokens=True)

    def sequence_logprob(self, misinformation, response, evidence=""):
        prompt = self.prompt(misinformation, evidence)
        source = self.tokenizer(
            prompt, return_tensors="pt", truncation=True, max_length=256
        ).to(self.device)

        target = self.tokenizer(
            response, return_tensors="pt", truncation=True, max_length=128
        ).input_ids.to(self.device)

        labels = target.clone()
        labels[labels == self.tokenizer.pad_token_id] = -100

        out = self.model(
            input_ids=source.input_ids,
            attention_mask=source.attention_mask,
            labels=labels,
        )
        # HF loss is mean negative log likelihood.
        return -out.loss
