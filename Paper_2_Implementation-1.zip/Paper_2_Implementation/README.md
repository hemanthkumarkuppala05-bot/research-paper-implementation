# Paper 2 — Lightweight RL Counter-Misinformation Response Generation

**Paper:** He et al. (2023), *Reinforcement Learning-based Counter-Misinformation Response Generation: A Case Study of COVID-19 Vaccine Misinformation.*

This repository implements the main methodology as a resource-efficient proof of concept.

## What is implemented

The system takes a misinformation claim and generates a counter-misinformation response. A supervised warm-up teaches a small sequence-to-sequence model to generate reference responses. Reinforcement learning then improves generated responses using a combined reward.

Reward components:

1. **Relevance** — response should be related to the misinformation claim.
2. **Refutation** — response should challenge/correct the misinformation.
3. **Factual/evidence alignment** — response should remain close to the supplied evidence/reference.
4. **Politeness** — simple penalty for insulting/aggressive language.
5. **Fluency** — penalizes empty/repetitive output.

## Computational modification

The original research uses a larger generation/RL setup and COVID-19 misinformation resources. For a 10-mark assessment, this implementation uses:

- `google/flan-t5-small` instead of a large generator.
- A small CSV subset.
- Shorter sequence length.
- Small batch size.
- Few supervised and RL epochs.
- Lightweight, transparent reward functions instead of expensive external evaluators.

These changes are made so the methodology can run on a laptop or free Colab GPU. The implementation is therefore a **proof of concept**, not an exact reproduction of the paper's reported scores.

## Dataset

CSV columns:

```text
misinformation,response,evidence
```

Example:

```csv
misinformation,response,evidence
"Vaccines contain microchips","There is no credible evidence that approved vaccines contain tracking microchips.","Reliable health authorities report no evidence of tracking chips in vaccines."
```

A sample file is included at `data/sample.csv`.

## Run

```bash
pip install -r requirements.txt

python train.py   --csv data/sample.csv   --model_name google/flan-t5-small   --output_dir outputs   --sup_epochs 1   --rl_epochs 1
```

Evaluate:

```bash
python evaluate.py --csv data/sample.csv --checkpoint outputs
```

Generate a response:

```bash
python inference.py   --checkpoint outputs   --misinformation "Vaccines contain tracking microchips"   --evidence "There is no credible evidence that approved vaccines contain tracking chips."
```

## Pipeline

```text
Misinformation
      |
      v
FLAN-T5-small generator
      |
      v
Candidate response
      |
      v
+------------------------------+
| Reward evaluator             |
| relevance                    |
| refutation                   |
| factual/evidence alignment   |
| politeness                   |
| fluency                      |
+------------------------------+
      |
      v
Combined reward
      |
      v
REINFORCE policy update
      |
      v
Improved response generator
```

## Assessment explanation

The important research idea is not just text generation. The response generator is treated as a policy. It produces a response, the response is evaluated by multiple quality signals, those signals are combined into a reward, and the generator is updated toward responses receiving higher reward.

Do not report the paper's original experimental numbers as results from this implementation.
