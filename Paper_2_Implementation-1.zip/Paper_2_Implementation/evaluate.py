import argparse
import numpy as np
from dataset import load_csv
from model import CounterMisinformationGenerator
from rewards import combined_reward


def main(args):
    df = load_csv(args.csv, args.max_rows)
    generator = CounterMisinformationGenerator(args.checkpoint)

    scores = []
    for _, row in df.iterrows():
        response = generator.generate(
            row["misinformation"], row["evidence"],
            max_new_tokens=args.max_new_tokens,
            do_sample=False,
        )
        score, parts = combined_reward(
            row["misinformation"], response,
            row["evidence"], row["response"]
        )
        scores.append(score)

        print("\nMISINFORMATION:", row["misinformation"])
        print("GENERATED:", response)
        print("REFERENCE:", row["response"])
        print("REWARD:", round(score, 4), parts)

    print("\nAverage reward:", round(float(np.mean(scores)), 4))


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--csv", default="data/sample.csv")
    p.add_argument("--checkpoint", default="outputs")
    p.add_argument("--max_rows", type=int, default=100)
    p.add_argument("--max_new_tokens", type=int, default=64)
    main(p.parse_args())
