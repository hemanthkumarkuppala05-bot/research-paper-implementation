import argparse
import os
import random

import numpy as np
import torch
import torch.nn.functional as F
from torch.optim import AdamW
from torch.utils.data import DataLoader
from tqdm import tqdm
from transformers import AutoTokenizer

from dataset import load_csv, JointDataset
from model import JointRumorModel
from rl_selector import RLSelector, epsilon_greedy_action, reinforce_loss


def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def main(args):
    seed_everything(args.seed)

    device = torch.device(
        "cuda" if torch.cuda.is_available() else "cpu"
    )

    os.makedirs(args.output_dir, exist_ok=True)

    print("Device:", device)

    df = load_csv(args.csv, args.max_rows)

    tokenizer = AutoTokenizer.from_pretrained(args.model_name)

    dataset = JointDataset(
        df,
        tokenizer,
        max_length=args.max_length,
    )

    loader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=True,
    )

    model = JointRumorModel(
        model_name=args.model_name,
        num_stance=4,
        num_veracity=4,
    ).to(device)

    selector = RLSelector(
        model.encoder.config.hidden_size
    ).to(device)

    optimizer = AdamW(
        list(model.parameters()) +
        list(selector.parameters()),
        lr=args.lr,
    )

    for epoch in range(args.epochs):

        model.train()
        selector.train()

        epoch_loss = 0.0

        progress = tqdm(
            loader,
            desc=f"Epoch {epoch + 1}/{args.epochs}",
        )

        for batch in progress:

            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)

            stance_labels = batch["stance"].to(device)
            veracity_labels = batch["veracity"].to(device)

            stance_logits, veracity_logits, features = model(
                input_ids,
                attention_mask,
            )

            stance_loss = F.cross_entropy(
                stance_logits,
                stance_labels,
            )

            veracity_loss = F.cross_entropy(
                veracity_logits,
                veracity_labels,
            )

            joint_loss = (
                stance_loss +
                args.veracity_weight * veracity_loss
            )

            # Reward is based on the correctness of both tasks.
            with torch.no_grad():

                stance_correct = (
                    stance_logits.argmax(dim=-1)
                    == stance_labels
                ).float()

                veracity_correct = (
                    veracity_logits.argmax(dim=-1)
                    == veracity_labels
                ).float()

                reward = (
                    0.5 * stance_correct +
                    0.5 * veracity_correct
                )

            # RL retain/discard decision.
            actions, probabilities = epsilon_greedy_action(
                selector,
                features.detach(),
                epsilon=args.epsilon,
            )

            retain = actions.float()

            # Retained examples get full loss.
            # Discarded examples receive a small weight so that
            # training remains stable during this lightweight demo.
            weighted_joint_loss = (
                joint_loss *
                (args.discard_weight +
                 (1.0 - args.discard_weight) * retain)
            ).mean()

            rl_loss = reinforce_loss(
                selector,
                features.detach(),
                actions,
                reward,
            )

            loss = (
                weighted_joint_loss +
                args.rl_weight * rl_loss
            )

            optimizer.zero_grad()
            loss.backward()

            torch.nn.utils.clip_grad_norm_(
                list(model.parameters()) +
                list(selector.parameters()),
                max_norm=1.0,
            )

            optimizer.step()

            epoch_loss += loss.item()

            progress.set_postfix(
                loss=f"{loss.item():.4f}",
                reward=f"{reward.mean().item():.3f}",
            )

        average_loss = epoch_loss / max(len(loader), 1)

        print(
            f"Epoch {epoch + 1}: "
            f"average_loss={average_loss:.4f}"
        )

    checkpoint = {
        "model": model.state_dict(),
        "selector": selector.state_dict(),
        "model_name": args.model_name,
        "stance_labels": [
            "Support",
            "Deny",
            "Question",
            "Comment",
        ],
        "veracity_labels": [
            "Non-Rumor",
            "True Rumor",
            "False Rumor",
            "Unverified Rumor",
        ],
    }

    path = os.path.join(
        args.output_dir,
        "checkpoint.pt",
    )

    torch.save(checkpoint, path)

    tokenizer.save_pretrained(args.output_dir)

    print("Saved:", path)


if __name__ == "__main__":

    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--csv",
        default="data/sample.csv",
    )

    parser.add_argument(
        "--model_name",
        default="distilbert-base-uncased",
    )

    parser.add_argument(
        "--output_dir",
        default="outputs",
    )

    parser.add_argument(
        "--epochs",
        type=int,
        default=2,
    )

    parser.add_argument(
        "--batch_size",
        type=int,
        default=4,
    )

    parser.add_argument(
        "--max_length",
        type=int,
        default=128,
    )

    parser.add_argument(
        "--max_rows",
        type=int,
        default=100,
    )

    parser.add_argument(
        "--lr",
        type=float,
        default=2e-5,
    )

    parser.add_argument(
        "--epsilon",
        type=float,
        default=0.2,
    )

    parser.add_argument(
        "--rl_weight",
        type=float,
        default=0.2,
    )

    parser.add_argument(
        "--veracity_weight",
        type=float,
        default=1.0,
    )

    parser.add_argument(
        "--discard_weight",
        type=float,
        default=0.25,
    )

    parser.add_argument(
        "--seed",
        type=int,
        default=42,
    )

    args = parser.parse_args()

    main(args)
